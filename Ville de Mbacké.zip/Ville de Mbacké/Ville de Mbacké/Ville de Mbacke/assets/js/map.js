$(window).on('load', function() { // makes sure the whole site is loaded 
    $('#preloader').fadeOut('slow',function(){$(this).remove();});
});

$(document).ready(function() {
  $.ajaxSetup({ cache: false });
  loadLayerConfig();
  initDrawSaveButton();
});



//Init BaseMaps
var basemaps = {
  "OpenStreetMaps": L.tileLayer(
    "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    {
      minZoom: 2,
      maxZoom: 19,
      id: "osm.streets"
    }
  ),
  "Google-Map": L.tileLayer(
    "https://mt1.google.com/vt/lyrs=r&x={x}&y={y}&z={z}",
    {
      minZoom: 2,
      maxZoom: 19,
      id: "google.street"
    }
  ),
  "GoogleSatellite": L.tileLayer(
    "https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}",
    {
      minZoom: 2,
      maxZoom: 19,
      id: "google.satellite"
    }
  ),
  "Google-Hybrid": L.tileLayer(
    "https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}",
    {
      minZoom: 2,
      maxZoom: 19,
      id: "google.hybrid"
    }
  ),
  "DBCarto": L.tileLayer(
    "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",
    {
      minZoom:2,
      maxZoom:20,
      id:'DBCarto'
    }
  ),
  "Nat GEO": L.tileLayer(
    "https://server.arcgisonline.com/ArcGIS/rest/services/NatGeo_World_Map/MapServer/tile/{z}/{y}/{x}",
    {
      minZoom:2,
      maxZoom:20,
      id:'NatGEO'
    }
  ),
  "World_Imagery": L.tileLayer(
    "http://server.arcgisonline.com/ArcGIS/rest/services//World_Imagery/MapServer/tile/{z}/{y}/{x}",
    {
      minZoom:2,
      maxZoom:20,
      id:'World_Imagery'
    }
  )
};





var overlays = {
 
  
  };
  

//Render Main Map
var map = L.map("map", {
  zoomControl: false,
  attributionControl: false,
  center: [14.80143855291984,-15.9064865112304],
  zoom: 12,
  editable: true,
  layers: [basemaps.GoogleSatellite]
});




//Init Zoom Control
L.control.zoom({
  position: "topleft"
  
}).addTo(map);

//Init Sidebar Control
var sidebar = L.control.sidebar({
  autopan: false,
  container: "sidebar",
  position: "right"
}).addTo(map);


 
//Init Layer Control
var layerControl = L.control.layers(
  basemaps, 
  overlays,
  {
    position: "topright",
    collapsed: false,
    tileX: 0,  // Coordonnée X de la prévisualisation
    tileY: 0,  // Coordonnée Y de la prévisualisation
     tileZ: 1 
  }
).addTo(map);





//************************************************************************************************
//************************Partie Insertion des données GEOJSON************************************
//********************************************************************************************* */


		// création d'une couche geoJson qui appelle le fichier "quartier.geojson"			
		var quartier = $.getJSON("data/Quartier.geojson",function(dataQuartier)
    
					{L.geoJson( dataQuartier, 
						{style: function(feature)
							{	
							// paramétrage de la symbologie de la couche "quartier"
							return { color: "green", weight: 2, fillColor: '#34C21B', fillOpacity: .2 };
							},
		onEachFeature: function( feature, layer )
				{
				// paramétrage de la popup de la couche "quartier"	
				layer.bindPopup( "<b><u>Description du Quartier </u></b><br><b>  NOM : </b>" + feature.properties.Nom+ '<br>'
				               + "<b><u> </u></b><br><b> Population(hbts) : </b>" + feature.properties.Population+ '<br>'
							   + "<b><u></u></b><br><b> Superficie(Km²) : </b>" + feature.properties.Superficie
				 )
				}
		}).addTo(map);
		});

    // création d'une couche geoJson qui appelle le fichier "route.geojson"													
    var Route= $.getJSON("data/route.geojson",function(data){
      var iconeRoute = L.icon({
        iconUrl: 'assets/icon/route.png',
        iconSize: [5, 5]
                });
  // L.geoJson function is used to parse geojson file and load on to map
  L.geoJson(data,
  
    
    {style: function(data)
      
      {	
      // paramétrage de la symbologie de la couche "quartier"
      return { color: "red", weight: 2, fillColor: 'red', fillOpacity: 0 ,dashArray: '10,15',
      lineJoin: 'round'  };
      
      },
      
      onEachFeature: function(feature, featureLayer) {
        featureLayer.bindPopup('<b><u>Description de la route</u></b><br>'
        + "<b>Nom : </b>" + feature.properties.Name+ '<br>' 
        + "<b>Longueur(m²) : </b>" + feature.properties.Longeur+ '<br>' 
        + "<b>Type : </b>" + feature.properties.Type+ '<br>'
        + "<b>Etat : </b>" + feature.properties.Etat+ '<br>'
        + "<b>Quartier : </b>" + feature.properties.Quartiers
        );
            
        }  
  }).addTo(map);
  });


  


     // création d'une couche geoJson qui appelle le fichier "hopital.geojson"													
     var hopital= $.getJSON("data/hopital.geojson",function(dataHopital)
     // icone Hopital	
     {var iconeHopital = L.icon({
           iconUrl: 'assets/icon/hopital.png',
           iconSize: [15, 17]
                   });
 // fon ction pointToLayer qui ajoute la couche "Quartier" à la carte, selon la symbologie "iconeCinema", et paramètre la popup
 L.geoJson(dataHopital,{
 pointToLayer: function(feature,latlng){
 var marker = L.marker(latlng,{icon: iconeHopital});
 marker.bindPopup('<b><u>Description du Poste de Santé</u></b><br>'
  + "<b>Nom : </b>" + feature.properties.Name+ '<br>' 
  + "<b>Type : </b>" + feature.properties.Type+ '<br>' 
  + "<b>Responsable : </b>" + feature.properties.Responsabl+ '<br>'
  + "<b>Quartier : </b>" + feature.properties.Quartiers
  );
 return marker;
 }
 }).addTo(map);
     });		
 

  
//************************************************************************************************
//************************END Insertion des données GEOJSON************************************
//********************************************************************************************* */

ctlEchel= L.control.scale().addTo(map);



//Move Layers control to sidebar
var layerControlContainer = layerControl.getContainer();
$("#layercontrol").append(layerControlContainer);
$(".leaflet-control-layers-list").prepend("<strong class='title'>Base Maps</strong><br>");
$(".leaflet-control-layers-separator").after("<br><strong class='title'>Layers</strong><br>");

//Handle Map click to Display Lat/Lng
map.on('click', function(e) {
  $("#latlng").html(e.latlng.lat + ", " + e.latlng.lng);
	$("#latlng").show();
});

//Handle Copy Lat/Lng to clipboard
$('#latlng').click(function(e) {
  var $tempElement = $("<input>");
	$("body").append($tempElement);
	$tempElement.val($("#latlng").text()).select();
	document.execCommand("Copy");
	$tempElement.remove();
	alert("Copied: "+$("#latlng").text());
	$("#latlng").hide();
});


//Init Editable(Cosmetic) Layer for Leaflet Draw
var editableLayers = new L.FeatureGroup().addTo(map);
layerControl.addOverlay(editableLayers, "Cosmetic Layer");

//Init Leaflet Draw
var drawControl = new L.Control.Draw({
  position: "topleft",
  draw: {
    polyline: true,
    polygon: {
      allowIntersection: false, // Restricts shapes to simple polygons
      drawError: {
        color: "#e1e100", // Color the shape will turn when intersects
        message: "<strong>Oh snap!<strong> you can't draw that!" // Message that will show when intersect
      }
    },
    circle: true,
    rectangle: true,
    circlemarker: false, // Turns off this drawing tool
    marker: true
  },
  edit: {
    featureGroup: editableLayers, //REQUIRED!!
    remove: true
  }
}).addTo(map);

//On Draw Create Event
map.on(L.Draw.Event.CREATED, function(e) {
  var type = e.layerType,
    layer = e.layer;

  if (type === "marker") {
    layer
      .bindPopup(
        "LatLng: " + layer.getLatLng().lat + "," + layer.getLatLng().lng
      )
      .openPopup();
  }

  editableLayers.addLayer(layer);
  console.log("Draw Create", JSON.stringify(editableLayers.toGeoJSON()));
  /*$(".drawercontainer .drawercontent").html(
    JSON.stringify(editableLayers.toGeoJSON())
  );*/
});

//On Draw Edit Event
map.on(L.Draw.Event.EDITED, function(e) {
  console.log("Draw Edit", JSON.stringify(editableLayers.toGeoJSON()));
  editableLayers.removeLayer(selectedFeature);
  /*$(".drawercontainer .drawercontent").html(
    JSON.stringify(editableLayers.toGeoJSON())
  );*/
});

//On Draw Delete Event
map.on(L.Draw.Event.DELETED, function(e) {
  console.log("Draw Delete", JSON.stringify(editableLayers.toGeoJSON()));
  //$(".drawercontainer .drawercontent").html("");
});

var drawEditMode = false;

//Edit Button Clicked
$('#toggledraw').click(function(e) {
  getSelectedLayers();
  if($(".leaflet-draw").is(":hidden"))
  {
    drawEditMode = true;
    $(this).find("i").css("color","rgb(0, 255, 0)");
    //console.log($(this).find("i::before").css("color"));
  }
  else
  {
    drawEditMode = false;
    $(this).find("i").css("color","rgb(255, 255, 255)");
  }
  $(".leaflet-draw").fadeToggle("fast", "linear");
  $(".leaflet-draw-toolbar").fadeToggle("fast", "linear");
  this.blur();
  return false;
});

//Init Map Bounds
var mapBounds=map.getBounds();
var bounds= new L.latLngBounds();

//Init Feature Selection
var selectedFeature = null;
var previousSelectedFeature = null;
var parentLayer = null;


var rect1 = {color: "#ff1100", weight: 3};
var rect2 = {color: "#0000AA", weight: 1, opacity:0, fillOpacity:0};
var miniMap = new L.Control.MiniMap(osm.streets, { toggleDisplay: true, position: left,  aimingRectOptions : rect1, shadowRectOptions: rect2}).addTo(map);




var selectedFeatureName = [];

function setSelectedLayers() {
  selectedFeatureName = [];
  $.each(map._layers, function (ml) {
    if (map._layers[ml].feature && map._layers[ml].feature.properties.selected === true) {
      selectedFeatureName.push(map._layers[ml]);
    }
  });
  //console.log(selectedFeatureName);
  //$('#selectedFeatures').text( selectedFeatureName );
  //$('#selectedCount').text( selectedFeatureName.length );
};

function getSelectedLayers() {
  $.each(selectedFeatureName, function (ml) {
    if (selectedFeatureName[ml].feature && selectedFeatureName[ml].feature.properties.selected === true) {
      if(selectedFeatureName[ml].editEnabled()) {
        selectedFeatureName[ml].disableEdit();
      }  
      else
      {
        selectedFeatureName[ml].enableEdit();
      }
    }
  });
  //console.log(selectedFeatureName);
  //$('#selectedFeatures').text( selectedFeatureName );
  //$('#selectedCount').text( selectedFeatureName.length );
};

//Draw Export Layer Button
function initDrawSaveButton() {
  var saveFileElem = '<a class="leaflet-draw-edit-edit leaflet-disabled" href="javascript:ExportGeoJSON();" id="ExportGeoJSON" title="No layers to Save"><span class="sr-only">Save layers to file</span></a>';
  $("#map > div.leaflet-control-container > div.leaflet-top.leaflet-left > div.leaflet-draw.leaflet-control > div:nth-child(2) > div").append(saveFileElem);
}

//Draw Export Layer Handler
function ExportGeoJSON() {
  if($(".leaflet-draw-edit-edit").hasClass("leaflet-disabled"))
  {
    alert("Nothing to save!");
    return false;
  }
  else
  {
     // Extract GeoJson from featureGroup
    var data = editableLayers.toGeoJSON();

    // Stringify the GeoJson
    var convertedData = new Blob([JSON.stringify(data)], {type: "text/plain;charset=utf-8"});
    saveAs(convertedData, "data.geojson");
  }
}

function updateDrawTools()
{
  if($(".leaflet-draw-edit-edit").first().hasClass('leaflet-disabled'))
  {
    $("#ExportGeoJSON").attr("title", "No Layers to Export")
    $("#ExportGeoJSON").addClass("leaflet-disabled");
  }
  else
  {
    $("#ExportGeoJSON").attr("title", "Export Layers to GeoJSON")
    $("#ExportGeoJSON").removeClass("leaflet-disabled");
  }
}

setInterval(updateDrawTools, 1000);




